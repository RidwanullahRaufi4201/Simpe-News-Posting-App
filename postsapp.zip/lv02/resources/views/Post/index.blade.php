@extends('Layout.master')

@section('page-title')
{{$page}}
@endsection
@section('content')

<div class="container">
    <div class="row justify-content-center mt-2">
        <div class="col-md-10 mx-auto ">
            @foreach ($posts as $post)
            <div class="card mb-3 w-50 mx-auto">
                <img src='{{asset("uploads/images/$post->image")}}' class="card-img-top " alt="...">
                <div class="card-body">
                  <h5 class="card-title">{{$post->title}}</h5>
                  <p class="card-text">{{$post->description}}</p>
                  <p class="card-text"><small class="text-muted">Last updated {{$post->updated_at}}</small></p>
                </div>
              </div>
              
            @endforeach
           
        </div>
    </div>
</div>

@endsection