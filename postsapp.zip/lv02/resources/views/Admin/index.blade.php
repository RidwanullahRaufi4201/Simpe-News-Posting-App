@extends('Layout.master')

@section('page-title')
{{$page}}
@endsection
@section('content')

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8 mt-3">
            <div class="m-2">
                <a href="{{route('admin.create')}}" class="btn btn-primary  btn-sm">Create Post</a>
            </div>
            <table class="table table-striped ">
                <tr>
                    <th>Id</th>
                    <th>Title</th>
                    <th>Image</th>
                    <th>Description</th>
                    <th>Action</th>
                </tr>
                @foreach ($posts as $post)
                    <tr>
                        <td>{{$post->id}}</td>
                        <td>{{$post->title}}</td>
                        <td><img src="{{asset("uploads/images/$post->image")}}" class="w-50 " alt=""></td>
                        <td>{{$post->description}}</td>
                        <td><a href="{{route('admin.delete',['id'=>$post->id])}}"><i class="fa fa-trash"></i></a>|<a href="{{route('admin.edit',['id'=>$post->id])}}"><i class="fa fa-edit"></i></a></td>
                    </tr>
                @endforeach
            </table>
        </div>
    </div>
</div>


@endsection