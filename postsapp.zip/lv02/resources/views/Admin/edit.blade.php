@extends('Layout.master')

@section('page-title')
{{$page}}
@endsection
@section('content')

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-6 mt-3">
            <div class="card">
                <div class="card-body">
                  <form action="{{route('admin.update',['id'=>$post->id])}}" method="post" class="p-3" enctype="multipart/form-data">
                    @csrf
                    <div class="from-group">
                        <label for="postTitle" class="m-1 fw-bold">Title</label>
                        <input type="text" class="form-control" value="{{$post->title}}" name="title">
                    </div>
                    <div class="from-group">
                        <label for="postImage" class="m-1 fw-bold">Image</label>
                        <input type="file" class="form-control" name="image">
                    </div>
                    <div class="from-group">
                        <label for="postDescription" class="m-1 fw-bold">Description</label>
                        <input type="text" class="form-control" value="{{$post->description}}" name="description">
                    </div>
                    <div class="from-group">
                       
                        <input type="submit" value="Post" class="btn  btn-primary mt-1">
                    </div>
                  </form>
                </div>
              </div>
        </div>
    </div>
</div>


@endsection