

<?php $__env->startSection('page-title'); ?>
<?php echo e($page); ?>

<?php $__env->stopSection(); ?>
<?php $__env->startSection('content'); ?>

<div class="container">
    <div class="row justify-content-center">
        <div class="col-md-8 mt-3">
            <div class="m-2">
                <a href="<?php echo e(route('admin.create')); ?>" class="btn btn-primary  btn-sm">Create Post</a>
            </div>
            <table class="table table-striped ">
                <tr>
                    <th>Id</th>
                    <th>Title</th>
                    <th>Image</th>
                    <th>Description</th>
                    <th>Action</th>
                </tr>
                <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <tr>
                        <td><?php echo e($post->id); ?></td>
                        <td><?php echo e($post->title); ?></td>
                        <td><img src="<?php echo e(asset("uploads/images/$post->image")); ?>" class="w-50 " alt=""></td>
                        <td><?php echo e($post->description); ?></td>
                        <td><a href="<?php echo e(route('admin.delete',['id'=>$post->id])); ?>"><i class="fa fa-trash"></i></a>|<a href="<?php echo e(route('admin.edit',['id'=>$post->id])); ?>"><i class="fa fa-edit"></i></a></td>
                    </tr>
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </table>
        </div>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make('Layout.master', \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\Users\Ridwanullah Raufi\Desktop\Laravel\lv02\resources\views/Admin/index.blade.php ENDPATH**/ ?>