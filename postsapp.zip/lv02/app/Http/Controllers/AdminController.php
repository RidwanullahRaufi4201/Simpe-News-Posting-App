<?php

namespace App\Http\Controllers;
use App\Models\Post;
use Illuminate\Http\Request;

class AdminController extends Controller
{
    public function index()
    {
        return view('Admin.index')
                    ->with('page','admin')
                    ->with('posts',Post::all());
    }
    
    public function createPost()
    {
        return view('Admin.createPost')
                     ->with('page','admin');
    }

    public function store(Request $request)
    {
          $request->validate([
            'title'=>'required|min:5',
            'image'=>'required:image',
            'description'=>'required:min:10'
          ]);
          $image_new_name='';
     if($request->has('image'))
     {
        $image=$request->image;
        $image_new_name=$image->getClientOriginalName();
        $image->move('uploads/images',$image_new_name);
     }
          Post::create([
              'title'=>$request->title,
              'image'=>$image_new_name,
              'description'=>$request->description,
          ]);

          return redirect()->route('admin.index');
    }


    public function delete($id)
    {
        $post=Post::FindOrFail($id);
        unlink('uploads/images/'.$post->image);
        Post::FindOrFail($id)->delete();
     
        return redirect()->route('admin.index');

    }


    public function edit(Post $id)
    {
        return view('Admin.edit')
                  ->with('page','admin')
                  ->with('post',$id);
    }

    public function update(Request $request, $id)
    {
           
          $request->validate([
            'title'=>'required|min:5',
            'image'=>'image',
            'description'=>'required:min:10'
          ]);
           $post=Post::Find($id); 
           if($request->has('image'))
           {
               unlink('uploads/images/'.$post->image);
               $image=$request->image;
               $image_new_name =$image->getClientOriginalName();
               $image->move('uploads/images',$image_new_name);
               $post->image=$image_new_name;
               
               
           }
           $post->title=$request->title;
           $post->description=$request->description;
           $post->save();

          return redirect()->route('admin.index');
    }
}
