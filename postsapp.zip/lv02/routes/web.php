<?php

use App\Http\Controllers\AdminController;
use App\Http\Controllers\PostController;
use Illuminate\Support\Facades\Route;

/*
|--------------------------------------------------------------------------
| Web Routes
|--------------------------------------------------------------------------
|
| Here is where you can register web routes for your application. These
| routes are loaded by the RouteServiceProvider and all of them will
| be assigned to the "web" middleware group. Make something great!
|
*/

Route::get('/',[AdminController::class,'index'])->name('admin.index');
Route::get('post',[PostController::class,'index'])->name('post.index');
Route::get('createPost',[AdminController::class,'createPost'])->name('admin.create');
Route::post('store',[AdminController::class,'store'])->name('admin.store');
Route::get('edit/{id}',[AdminController::class,'edit'])->name('admin.edit');
Route::get('delete/{id}',[AdminController::class,'delete'])->name('admin.delete');
Route::post('update/{id}',[AdminController::class,'update'])->name('admin.update');



